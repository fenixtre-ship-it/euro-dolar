package com.example.divisas

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.w3c.dom.Element
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.math.sqrt

val PAIRS = ("EURUSD GBPUSD USDJPY USDCHF AUDUSD USDCAD NZDUSD EURGBP EURJPY EURAUD EURCAD EURCHF " +
    "EURNZD GBPJPY GBPCHF GBPAUD GBPCAD GBPNZD CHFJPY AUDJPY AUDCAD AUDCHF AUDNZD NZDJPY NZDCHF " +
    "NZDCAD CADJPY CADCHF USDMXN USDTRY USDZAR USDSGD USDCNH USDHKD USDNOK USDSEK USDDKK EURTRY " +
    "EURMXN EURZAR XAUUSD XAGUSD BTCUSD ETHUSD").split(" ")

val NAMES = mapOf(
    "EUR" to "euro", "USD" to "dólar", "GBP" to "libra esterlina", "JPY" to "yen",
    "CHF" to "franco suizo", "AUD" to "dólar australiano", "CAD" to "dólar canadiense",
    "NZD" to "dólar neozelandés", "MXN" to "peso mexicano", "TRY" to "lira turca",
    "ZAR" to "rand sudafricano", "SGD" to "dólar de Singapur", "CNH" to "yuan",
    "HKD" to "dólar de Hong Kong", "NOK" to "corona noruega", "SEK" to "corona sueca",
    "DKK" to "corona danesa", "XAU" to "oro", "XAG" to "plata", "BTC" to "bitcoin", "ETH" to "ethereum"
)

fun label(p: String) = p.take(3) + "/" + p.drop(3)
fun decimals(p: String) = when {
    p.endsWith("JPY") -> 3
    p in setOf("XAUUSD", "XAGUSD", "BTCUSD", "ETHUSD") -> 2
    else -> 4
}
fun yahooSymbol(p: String) = when (p) {
    "XAUUSD" -> "GC=F"; "XAGUSD" -> "SI=F"; "BTCUSD" -> "BTC-USD"; "ETHUSD" -> "ETH-USD"
    else -> "$p=X"
}

data class News(val title: String, val source: String, val time: Long, val link: String)
data class Forecast(val mid: List<Double>, val lo: List<Double>, val hi: List<Double>, val pct: Double)

private fun httpGet(url: String): String = URL(url).openConnection().run {
    connectTimeout = 10_000
    readTimeout = 10_000
    setRequestProperty("User-Agent", "Mozilla/5.0")
    setRequestProperty("Cache-Control", "no-cache")
    useCaches = false
    getInputStream().bufferedReader().use { it.readText() }
}

// Precios (Yahoo Finance, API no oficial sin clave)
suspend fun fetchCloses(pair: String, range: String, interval: String): List<Double> = withContext(Dispatchers.IO) {
    val json = JSONObject(httpGet("https://query1.finance.yahoo.com/v8/finance/chart/${yahooSymbol(pair)}?range=$range&interval=$interval"))
    val arr = json.getJSONObject("chart").getJSONArray("result").getJSONObject(0)
        .getJSONObject("indicators").getJSONArray("quote").getJSONObject(0).getJSONArray("close")
    (0 until arr.length()).filter { !arr.isNull(it) }.map { arr.getDouble(it) }
}

suspend fun <T> attempt(block: suspend () -> T): T? =
    try { block() } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { null }

private fun rss(q: String, within: String): List<News> {
    val url = "https://news.google.com/rss/search?q=" + URLEncoder.encode("$q when:$within", "UTF-8") + "&hl=es&gl=ES&ceid=ES:es"
    val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(httpGet(url).byteInputStream())
    val items = doc.getElementsByTagName("item")
    val fmt = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.ENGLISH)
    return (0 until minOf(items.length, 40)).map { i ->
        val e = items.item(i) as Element
        fun t(tag: String) = e.getElementsByTagName(tag).item(0)?.textContent ?: ""
        News(t("title"), t("source"), runCatching { fmt.parse(t("pubDate"))!!.time }.getOrDefault(0L), t("link"))
    }
}

// Noticias de las últimas 24 h (si hay pocas, amplía a 7 días), ordenadas de más nueva a más antigua
suspend fun fetchNews(pair: String): List<News> = withContext(Dispatchers.IO) {
    val b = NAMES[pair.take(3)] ?: pair.take(3)
    val q = NAMES[pair.drop(3)] ?: pair.drop(3)
    var r = rss("$b $q cotización", "1d")
    if (r.size < 8) r = rss("$b $q cotización", "7d")
    if (r.isEmpty()) r = rss("$b cotización", "7d")
    r.sortedByDescending { it.time }.take(25)
}

fun ago(t: Long): String {
    if (t == 0L) return ""
    val m = (System.currentTimeMillis() - t) / 60000
    return when {
        m < 1 -> "ahora"
        m < 60 -> "hace $m min"
        m < 1440 -> "hace ${m / 60} h"
        else -> "hace ${m / 1440} d"
    }
}

// Proyección estadística: tendencia lineal de los últimos `win` puntos + cono de incertidumbre
fun forecast(closes: List<Double>, h: Int, win: Int): Forecast {
    val w = closes.takeLast(win)
    val n = w.size
    val xm = (n - 1) / 2.0
    val ym = w.average()
    val slope = w.indices.sumOf { (it - xm) * (w[it] - ym) } / w.indices.sumOf { (it - xm) * (it - xm) }
    val d = (1 until n).map { w[it] - w[it - 1] }
    val dm = d.average()
    val sd = sqrt(d.sumOf { (it - dm) * (it - dm) } / d.size)
    val last = w.last()
    val mid = (1..h).map { last + slope * it }
    val band = (1..h).map { 1.5 * sd * sqrt(it.toDouble()) }
    return Forecast(mid, mid.zip(band) { a, b -> a - b }, mid.zip(band) { a, b -> a + b }, (mid.last() / last - 1) * 100)
}

val BG = Color(0xFF0B0E11)
val SURF = Color(0xFF161A1E)
val CARD = Color(0xFF2B3139)
val GREEN = Color(0xFF0ECB81)
val RED = Color(0xFFF6465D)
val AMBER = Color(0xFFF0B90B)
val MUTED = Color(0xFF848E9C)
val TXT = Color(0xFFEAECEF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG.toArgb()
        window.navigationBarColor = BG.toArgb()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = AMBER, background = BG, surface = SURF,
                    onBackground = TXT, onSurface = TXT, surfaceVariant = CARD, onSurfaceVariant = MUTED
                )
            ) { App() }
        }
    }
}

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
        .clip(RoundedCornerShape(16.dp)).background(SURF).padding(16.dp),
    content = content
)

@Composable
fun Pill(text: String, color: Color) = Text(
    text, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(color.copy(alpha = 0.15f))
        .padding(horizontal = 8.dp, vertical = 4.dp)
)

@Composable
fun Chart(h: List<Double>, f: Forecast) {
    val trend = if (h.last() >= h.first()) GREEN else RED
    Canvas(Modifier.fillMaxWidth().height(180.dp).padding(vertical = 8.dp)) {
        val lo = minOf(h.min(), f.lo.min())
        val hi = maxOf(h.max(), f.hi.max())
        val rng = if (hi - lo > 0) hi - lo else 1.0
        val n = h.size + f.mid.size
        fun x(i: Int) = size.width * i / (n - 1)
        fun y(v: Double) = (size.height * (1 - (v - lo) / rng)).toFloat()
        val last = h.size - 1
        for (i in 0..3) {
            val gy = size.height * i / 3
            drawLine(Color(0x22FFFFFF), Offset(0f, gy), Offset(size.width, gy), 1f)
        }
        val hp = Path().apply {
            h.forEachIndexed { i, v -> if (i == 0) moveTo(x(i), y(v)) else lineTo(x(i), y(v)) }
        }
        val fill = Path().apply {
            addPath(hp); lineTo(x(last), size.height); lineTo(0f, size.height); close()
        }
        drawPath(fill, Brush.verticalGradient(listOf(trend.copy(alpha = 0.30f), Color.Transparent)))
        val band = Path().apply {
            moveTo(x(last), y(h.last()))
            f.hi.forEachIndexed { k, v -> lineTo(x(last + k + 1), y(v)) }
            for (k in f.lo.indices.reversed()) lineTo(x(last + k + 1), y(f.lo[k]))
            close()
        }
        drawPath(band, AMBER.copy(alpha = 0.14f))
        drawPath(hp, trend, style = Stroke(width = 4f))
        val pp = Path().apply {
            moveTo(x(last), y(h.last()))
            f.mid.forEachIndexed { k, v -> lineTo(x(last + k + 1), y(v)) }
        }
        drawPath(pp, AMBER, style = Stroke(width = 4f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))))
        drawCircle(trend, 8f, Offset(x(last), y(h.last())))
    }
}

@Composable
fun ForecastPanel(title: String, caption: String, h: List<Double>, f: Forecast, d: Int) {
    Panel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(caption, color = MUTED, fontSize = 11.sp)
            }
            Pill("${if (f.pct >= 0) "▲ Alcista" else "▼ Bajista"} %+.2f%%".format(f.pct), if (f.pct >= 0) GREEN else RED)
        }
        Chart(h, f)
        Text("Objetivo %.${d}f  ·  rango %.${d}f – %.${d}f".format(f.mid.last(), f.lo.last(), f.hi.last()),
            color = MUTED, fontSize = 12.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PairSheet(current: String, onPick: (String) -> Unit, onClose: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val q = query.replace("/", "").uppercase()
    val groups = listOf(
        "Principales" to PAIRS.take(7), "Cruces" to PAIRS.subList(7, 28),
        "Exóticos" to PAIRS.subList(28, 40), "Metales y cripto" to PAIRS.takeLast(4)
    ).map { (t, l) -> t to l.filter { it.contains(q) } }.filter { it.second.isNotEmpty() }
    ModalBottomSheet(onDismissRequest = onClose, containerColor = SURF) {
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Buscar par (ej. EUR, JPY, BTC)") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        LazyColumn(Modifier.weight(1f, fill = false).padding(horizontal = 16.dp)) {
            groups.forEach { (title, list) ->
                item {
                    Text(title, color = MUTED, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))
                }
                items(list.chunked(3)) { row ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { p ->
                            Text(
                                label(p), textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold,
                                color = if (p == current) BG else TXT,
                                modifier = Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                                    .background(if (p == current) AMBER else CARD)
                                    .clickable { onPick(p) }.padding(vertical = 12.dp)
                            )
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
fun App() {
    var pair by remember { mutableStateOf("EURUSD") }
    var d7 by remember { mutableStateOf<List<Double>>(emptyList()) }
    var h1 by remember { mutableStateOf<List<Double>>(emptyList()) }
    var m15 by remember { mutableStateOf<List<Double>>(emptyList()) }
    var news by remember { mutableStateOf<List<News>>(emptyList()) }
    var newsLoaded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var updated by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    var sheet by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    // Actualiza al cambiar de par, al pulsar "Actualizar" y cada 2 minutos
    LaunchedEffect(pair, tick) {
        d7 = emptyList(); h1 = emptyList(); m15 = emptyList(); news = emptyList()
        newsLoaded = false; error = null
        while (true) {
            val r = attempt { fetchCloses(pair, "3mo", "1d") }
            if (r != null) { d7 = r.takeLast(60); error = null } else error = "No se pudo cargar el precio. Revisa tu conexión."
            attempt { fetchCloses(pair, "5d", "1h") }?.let { h1 = it }
            attempt { fetchCloses(pair, "2d", "15m") }?.let { m15 = it }
            attempt { fetchNews(pair) }?.let { news = it; newsLoaded = true }
            updated = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            delay(2 * 60_000L)
        }
    }

    Scaffold(containerColor = BG, contentColor = TXT) { pad ->
        LazyColumn(Modifier.padding(pad)) {
            item {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        Modifier.clip(RoundedCornerShape(24.dp)).background(SURF)
                            .clickable { sheet = true }.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(label(pair), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("  ▾", color = AMBER, fontSize = 16.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        TextButton(onClick = { tick++ }) { Text("⟳ Actualizar", color = AMBER) }
                        if (updated.isNotEmpty()) Text("Actualizado $updated", color = MUTED, fontSize = 10.sp)
                    }
                }
            }
            if (d7.size < 5) {
                item { Text(error ?: "Cargando…", color = MUTED, modifier = Modifier.padding(16.dp)) }
            } else {
                item {
                    val d = decimals(pair)
                    val last = d7.last()
                    val prev = d7[d7.size - 2]
                    val ch = last - prev
                    val cal = Calendar.getInstance()
                    val minsLeft = 24 * 60 - (cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE))
                    val hDay = (minsLeft / 15).coerceIn(8, 64)
                    Column {
                        Panel {
                            Text("Precio actual", color = MUTED, fontSize = 13.sp)
                            Text("%.${d}f".format(last), fontSize = 40.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Pill("${if (ch >= 0) "▲" else "▼"} %+.${d}f  (%+.2f%%)".format(ch, ch / prev * 100),
                                if (ch >= 0) GREEN else RED)
                        }
                        if (m15.size >= 20) {
                            val s = m15.takeLast(64)
                            ForecastPanel("Hoy · resto del día",
                                "Últimas ${s.size / 4} h · proyección ${"%.1f".format(hDay / 4.0)} h",
                                s, forecast(s, hDay, 16), d)
                        }
                        if (h1.size >= 30) {
                            val s = h1.takeLast(72)
                            ForecastPanel("Próximos 3 días", "Últimas ${s.size} h · proyección 72 h",
                                s, forecast(s, 72, 48), d)
                        }
                        ForecastPanel("Próximos 7 días", "Últimos ${d7.size} cierres diarios · proyección 7 días",
                            d7, forecast(d7, 7, 30), d)
                        Panel {
                            Text("━ Histórico   ┅ Proyección   ▒ Rango probable", color = MUTED, fontSize = 11.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Estimaciones estadísticas basadas en la tendencia reciente. " +
                                    "No son una recomendación de inversión ni garantizan el resultado.",
                                color = MUTED, fontSize = 11.sp
                            )
                            error?.let { Text(it, color = MUTED, fontSize = 12.sp) }
                        }
                    }
                }
            }
            item {
                Text("Noticias · ${label(pair)}", fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 8.dp))
            }
            if (newsLoaded && news.isEmpty()) {
                item { Text("Sin noticias recientes para este par.", color = MUTED, modifier = Modifier.padding(horizontal = 16.dp)) }
            }
            items(news) { n ->
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp)).background(SURF)
                        .clickable { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(n.link))) }
                        .padding(14.dp)
                ) {
                    Text(n.title, fontSize = 15.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(6.dp))
                    Text("${n.source.uppercase()} · ${ago(n.time)}", fontSize = 11.sp, color = AMBER)
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
    if (sheet) PairSheet(pair, { pair = it; sheet = false }, { sheet = false })
}
